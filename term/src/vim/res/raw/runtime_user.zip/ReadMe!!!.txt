*AboutThisDirectory*

!!! This directory will be deleted when you uninstall DroidVim !!!
!!! Please back up regularly !!!

================
1. Vimfiles (.vimrc and .vim)

For Vim configuration files, see below:
"Long press menu > Help > Vimfiles"

================
2. Accessible directory

The directories that Vim (shell) can directly access are as follows.

App-specific private storage:
    $HOME - DroidVim's Home directory (This directory).

App-specific storage:
    $APPEXTHOME
    `[Internal storage]/Android/data/com.droidvim/files`

Shared storage:
    $INTERNAL_STORAGE
    Android 10 and before
        `/sdcard` or `/storage/emulated/0`.
    Android 11 and later
        `[Internal storage]/Android/data/com.droidvim/files`

!!! Uninstalling DroidVim will remove both App-specific storage !!!
!!! Please back up regularly !!!

 vim:tw=78:et:ft=help:norl:
