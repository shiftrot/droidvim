!!! This directory will be deleted when you uninstall this app. !!!
!!! Please back up regularly. !!!

- You can change Vim settings by creating ".vimrc" file in this directory.
  (Type ":help .vimrc" or "Long press menu" > "Edit .vimrc")
- You can use a plugin and color scheme by copying the files to the user runtime directory ($HOME/.vim).
- If you have Vimfiles (.vimrc and .vim), see "Help" > "Vimfiles" or overwrite the user runtime directory.
  For Android 10 and earlier, it is recommended to create a symbolic link.
  For Android 11 or later, use "File manager" or "Strorage" > "Backup/Restore" in the drawer menu.

!!! This directory will be deleted when you uninstall this app. !!!
!!! Please back up regularly. !!!
