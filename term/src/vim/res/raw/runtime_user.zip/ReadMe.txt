*AboutThisDirectory*

!!! This directory will be deleted when you uninstall DroidVim !!!
!!! Please back up regularly !!!

================
1. Vimfiles (.vimrc and .vim)

"Long press menu > help > vimfiles" or type "gx" to open the URL under the cursor.
https://droidterm-e8a40.firebaseapp.com/droidvim/index.html#vimfiles

================
2. Accessible directory

The directories that Vim (shell) can directly access are as follows.

App-specific private storage:
    $HOME - DroidVim's Home directory (This directory).

App-specific storage:
    $APPEXTHOME
    ([Internal storage]/Android/data/com.droidvim/files/home)

Shared storage:
    $INTERNAL_STORAGE

!!! Uninstalling DroidVim will remove both App-specific storage !!!
!!! Please back up regularly !!!

 vim:tw=78:et:ft=help:norl:
